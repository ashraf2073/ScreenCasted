/* Made par Ashraf */
package com.ashraf.screencast

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/** PCM format used for optional device-audio streaming (16-bit stereo). */
const val AUDIO_RATE = 44_100

/** Ordered by preference: USB first (highest bandwidth, steadiest), Bluetooth last. */
enum class LinkType(val label: String, val rank: Int) {
    USB("USB tethering", 0),
    HOTSPOT("Wi-Fi hotspot", 1),
    WIFI("Wi-Fi / LAN", 2),
    BLUETOOTH("Bluetooth PAN", 3)
}

data class Endpoint(val type: LinkType, val iface: String, val ip: String, val url: String)

data class StreamConfig(
    val maxEdge: Int = 1280,   // longest side of the streamed frame, in pixels
    val quality: Int = 60,     // JPEG quality 10..95
    val fps: Int = 30          // target frame rate 1..60
) {
    companion object {
        /** Applied automatically when Bluetooth PAN is the only link available. */
        val LOW_BANDWIDTH = StreamConfig(maxEdge = 480, quality = 35, fps = 10)
    }
}

data class UiState(
    val running: Boolean = false,
    val endpoints: List<Endpoint> = emptyList(),
    val pin: String = "",
    val viewers: Int = 0,
    val config: StreamConfig = StreamConfig(),
    val audio: Boolean = false,
    val error: String? = null
)

/** In-process bridge between [ScreenStreamService] and the Compose UI. */
object StreamState {
    val state = MutableStateFlow(UiState())
    fun update(block: (UiState) -> UiState) = state.update(block)
}
