/* Made par Ashraf */
package com.ashraf.screencast

import android.content.Context
import android.util.Log
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.MIME_HTML
import fi.iki.elonen.NanoHTTPD.MIME_PLAINTEXT
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import fi.iki.elonen.NanoHTTPD.newFixedLengthResponse
import fi.iki.elonen.NanoWSD
import fi.iki.elonen.NanoWSD.WebSocket
import fi.iki.elonen.NanoWSD.WebSocketFrame
import fi.iki.elonen.NanoWSD.WebSocketFrame.CloseCode
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.atomic.AtomicInteger

/**
 * Serves the browser viewer at "/" and the live stream on the "/ws" WebSocket.
 *
 * Wire format (binary frames): byte 0 = packet type, rest = payload
 *   0x01 -> JPEG video frame      0x02 -> 16-bit stereo PCM audio chunk
 * Text frames: server -> client {"type":"meta",...}; client -> server {"type":"config",...}
 *
 * Why JPEG over WebSocket instead of H.264? Browsers only expose WebCodecs on secure contexts
 * (https / localhost). A plain http://192.168.x.x page is not one, so JPEG + canvas is the
 * approach that works in every browser without certificates.
 */
class EmbeddedServer(
    private val context: Context,
    port: Int,
    private val pin: String,
    private val onViewers: (Int) -> Unit,
    private val onConfig: (StreamConfig) -> Unit
) : NanoWSD(port) {

    companion object {
        private const val TAG = "EmbeddedServer"
        const val PKT_VIDEO: Byte = 1
        const val PKT_AUDIO: Byte = 2
        private const val MAX_FAILS = 5
        private const val LOCK_MS = 60_000L
    }

    private val clients = ConcurrentHashMap.newKeySet<Client>()
    private val fails = ConcurrentHashMap<String, Pair<Int, Long>>()
    private val page: String by lazy {
        context.assets.open("viewer.html").bufferedReader().use { it.readText() }
    }

    fun hasViewers(): Boolean = clients.isNotEmpty()

    /** [packet] must start with PKT_VIDEO or PKT_AUDIO. The same array is shared by all clients. */
    fun broadcast(packet: ByteArray) {
        val video = packet[0] == PKT_VIDEO
        for (c in clients) if (video) c.pushVideo(packet) else c.pushAudio(packet)
    }

    fun shutdown() {
        clients.forEach { it.kill() }
        clients.clear()
        stop()
    }

    // ---- HTTP ----------------------------------------------------------------------------

    override fun serveHttp(session: IHTTPSession): Response {
        val res = when (session.uri) {
            "/", "/index.html" -> newFixedLengthResponse(Status.OK, MIME_HTML, page)
            "/health" -> newFixedLengthResponse(Status.OK, MIME_PLAINTEXT, "ok")
            else -> newFixedLengthResponse(Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
        }
        res.addHeader("Cache-Control", "no-store")
        res.addHeader("X-Content-Type-Options", "nosniff")
        res.addHeader("Referrer-Policy", "no-referrer")
        return res
    }

    // ---- WebSocket + auth ----------------------------------------------------------------

    override fun openWebSocket(handshake: IHTTPSession): WebSocket {
        val ip = handshake.remoteIpAddress ?: "unknown"
        val given = handshake.parameters["pin"]?.firstOrNull().orEmpty()
        val ok = !isLocked(ip) && MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())
        if (ok) fails.remove(ip) else registerFailure(ip)
        return Client(handshake, ok)
    }

    private fun isLocked(ip: String): Boolean {
        val (count, since) = fails[ip] ?: return false
        if (System.currentTimeMillis() - since > LOCK_MS) {
            fails.remove(ip)
            return false
        }
        return count >= MAX_FAILS
    }

    private fun registerFailure(ip: String) {
        val now = System.currentTimeMillis()
        fails.compute(ip) { _, old ->
            if (old == null || now - old.second > LOCK_MS) 1 to now else (old.first + 1) to old.second
        }
    }

    private fun metaJson(): String {
        val s = StreamState.state.value
        return JSONObject()
            .put("type", "meta")
            .put("audio", s.audio)
            .put("rate", AUDIO_RATE)
            .put("maxEdge", s.config.maxEdge)
            .put("quality", s.config.quality)
            .put("fps", s.config.fps)
            .toString()
    }

    /**
     * One connected browser. A dedicated pump thread does the (blocking) socket writes so a slow
     * viewer can never stall the encoder: at most one video frame waits in its queue (newer frames
     * are dropped), and audio is bounded and drops the oldest chunk first.
     */
    private inner class Client(handshake: IHTTPSession, private val authorized: Boolean) :
        WebSocket(handshake) {

        private val queue = LinkedBlockingDeque<ByteArray>(100)
        private val pendingVideo = AtomicInteger(0)
        @Volatile private var alive = true
        private var pump: Thread? = null

        override fun onOpen() {
            if (!authorized) {
                try {
                    close(CloseCode.PolicyViolation, "auth", false)
                } catch (e: IOException) {
                    Log.d(TAG, "close after bad PIN failed: ${e.message}")
                }
                return
            }
            clients.add(this)
            try {
                send(metaJson())
            } catch (e: IOException) {
                kill()
                return
            }
            pump = Thread({ pumpLoop() }, "ws-pump").apply { isDaemon = true; start() }
            onViewers(clients.size)
        }

        override fun onClose(code: CloseCode?, reason: String?, initiatedByRemote: Boolean) = kill()

        override fun onMessage(message: WebSocketFrame) {
            if (!authorized) return
            try {
                val json = JSONObject(message.textPayload)
                if (json.optString("type") != "config") return
                val cur = StreamState.state.value.config
                onConfig(
                    StreamConfig(
                        maxEdge = json.optInt("maxEdge", cur.maxEdge).coerceIn(240, 2560),
                        quality = json.optInt("quality", cur.quality).coerceIn(10, 95),
                        fps = json.optInt("fps", cur.fps).coerceIn(1, 60)
                    )
                )
            } catch (e: Exception) {
                Log.w(TAG, "Ignoring malformed client message", e)
            }
        }

        override fun onPong(pong: WebSocketFrame?) {}

        override fun onException(exception: IOException?) = kill()

        fun pushVideo(p: ByteArray) {
            if (!alive || pendingVideo.get() > 0) return          // viewer is behind: drop frame
            pendingVideo.incrementAndGet()
            if (!queue.offerLast(p)) pendingVideo.decrementAndGet()
        }

        fun pushAudio(p: ByteArray) {
            if (!alive) return
            while (!queue.offerLast(p)) {
                val dropped = queue.pollFirst()
                if (dropped != null && dropped[0] == PKT_VIDEO) pendingVideo.decrementAndGet()
            }
        }

        private fun pumpLoop() {
            try {
                while (alive) {
                    val p = queue.take()
                    try {
                        send(p)
                    } finally {
                        if (p[0] == PKT_VIDEO) pendingVideo.decrementAndGet()
                    }
                }
            } catch (e: InterruptedException) {
                // normal shutdown
            } catch (e: IOException) {
                Log.d(TAG, "Viewer went away: ${e.message}")
            }
            kill()
        }

        fun kill() {
            if (!alive) return
            alive = false
            pump?.interrupt()
            if (clients.remove(this)) onViewers(clients.size)
            try {
                close(CloseCode.NormalClosure, "bye", false)
            } catch (e: IOException) {
                // socket already gone
            }
        }
    }
}
