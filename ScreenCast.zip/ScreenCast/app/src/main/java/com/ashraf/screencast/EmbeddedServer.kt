/* Made par Ashraf */
package com.ashraf.screencast

import android.content.Context
import android.util.Log
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.MIME_HTML
import fi.iki.elonen.NanoHTTPD.MIME_PLAINTEXT
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import fi.iki.elonen.NanoHTTPD.newFixedLengthResponse
import fi.iki.elonen.NanoWSD
import fi.iki.elonen.NanoWSD.WebSocket
import fi.iki.elonen.NanoWSD.WebSocketFrame
import fi.iki.elonen.NanoWSD.WebSocketFrame.CloseCode
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.atomic.AtomicInteger

/**
 * Serves the browser viewer at "/" and the live stream on the "/ws" WebSocket.
 *
 * Wire format (binary frames): byte 0 = packet type, rest = payload
 *   0x01 -> JPEG video frame      0x02 -> 16-bit stereo PCM audio chunk
 * Text frames: server -> client {"type":"meta",...}; client -> server {"type":"config",...}
 *
 * Why JPEG over WebSocket instead of H.264? Browsers only expose WebCodecs on secure contexts
 * (https / localhost). A plain http://192.168.x.x page is not one, so JPEG + canvas is the
 * approach that works in every browser without certificates.
 */
class EmbeddedServer(
    private val context: Context,
    port: Int,
    private val pin: String,
    private val onViewers: (Int) -> Unit,
    private val onConfig: (StreamConfig) -> Unit
) : NanoWSD(port) {

    companion object {
        private const val TAG = "EmbeddedServer"
        const val PKT_VIDEO: Byte = 1
        const val PKT_AUDIO: Byte = 2
        private const val MAX_FAILS = 5
        private const val LOCK_MS = 60_000L
    }

    private val clients = ConcurrentHashMap.newKeySet<Client>()
    private val fails = ConcurrentHashMap<String, Pair<Int, Long>>()
    private val page: String by lazy {
        context.assets.open("viewer.html").bufferedReader().use { it.readText() }
    }

    fun hasViewers(): Boolean = clients.isNotEmpty()

    /** [packet] must start with PKT_VIDEO or PKT_AUDIO. The same array is shared by all clients. */
    fun broadcast(packet: ByteArray) {
        val video = packet[0] == PKT_VIDEO
        for (c in clients) if (video) c.pushVideo(packet) else c.pushAudio(packet)
    }

    fun shutdown() {
        clients.forEach { it.kill() }
        clients.clear()
        stop()
    }

    // ---- HTTP ----------------------------------------------------------------------------

    override fun serveHttp(session: IHTTPSession): Response {
        val res = when (session.uri) {
            "/", "/index.html" -> newFixedLengthResponse(Status.OK, MIME_HTML, page)
            "/health" -> newFixedLengthResponse(Status.OK, MIME_PLAINTEXT, "ok")
            else -> newFixedLengthResponse(Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
        }
        res.addHeader("Cache-Control", "no-store")
        res.addHeader("X-Content-Type-Options", "nosniff")
        res.addHeader("Referrer-Policy", "no-referrer")
        return res
    }

    // ---- WebSocket + auth ----------------------------------------------------------------

    override fun openWebSocket(handshake: IHTTPSession): WebSocket =
        Client(handshake, handshake.remoteIpAddress ?: "unknown")

    /** Seconds this address must still wait before trying again, or 0 if it may try now. */
    private fun lockSeconds(ip: String): Int {
        val (count, since) = fails[ip] ?: return 0
        val left = LOCK_MS - (System.currentTimeMillis() - since)
        if (left <= 0) {
            fails.remove(ip)
            return 0
        }
        return if (count >= MAX_FAILS) ((left + 999) / 1000).toInt() else 0
    }

    private fun registerFailure(ip: String) {
        val now = System.currentTimeMillis()
        fails.compute(ip) { _, old ->
            if (old == null || now - old.second > LOCK_MS) 1 to now else (old.first + 1) to old.second
        }
    }

    private fun metaJson(): String {
        val s = StreamState.state.value
        return JSONObject()
            .put("type", "meta")
            .put("audio", s.audio)
            .put("rate", AUDIO_RATE)
            .put("maxEdge", s.config.maxEdge)
            .put("quality", s.config.quality)
            .put("fps", s.config.fps)
            .toString()
    }

    /**
     * One connected browser. A dedicated pump thread does the (blocking) socket writes so a slow
     * viewer can never stall the encoder: at most one video frame waits in its queue (newer frames
     * are dropped), and audio is bounded and drops the oldest chunk first.
     */
    private inner class Client(handshake: IHTTPSession, private val ip: String) : WebSocket(handshake) {

        private val queue = LinkedBlockingDeque<ByteArray>(100)
        private val pendingVideo = AtomicInteger(0)
        @Volatile private var alive = true
        @Volatile private var authorized = false
        private var pump: Thread? = null

        override fun onOpen() {
            // A browser that never sends its PIN is dropped after 10 seconds.
            Thread({
                try {
                    Thread.sleep(10_000)
                    if (!authorized) kill()
                } catch (e: InterruptedException) {
                    // shutting down
                }
            }, "ws-auth-timeout").apply { isDaemon = true; start() }
        }

        override fun onClose(code: CloseCode?, reason: String?, initiatedByRemote: Boolean) = kill()

        override fun onMessage(message: WebSocketFrame) {
            try {
                val json = JSONObject(message.textPayload)
                when (json.optString("type")) {
                    "auth" -> if (!authorized) authenticate(json.optString("pin"))
                    "config" -> if (authorized) {
                        val cur = StreamState.state.value.config
                        onConfig(
                            StreamConfig(
                                maxEdge = json.optInt("maxEdge", cur.maxEdge).coerceIn(240, 2560),
                                quality = json.optInt("quality", cur.quality).coerceIn(10, 95),
                                fps = json.optInt("fps", cur.fps).coerceIn(1, 60)
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Ignoring malformed client message", e)
            }
        }

        private fun authenticate(raw: String) {
            val given = raw.filter { it.isDigit() }
            val wait = lockSeconds(ip)
            if (wait > 0) {
                Log.w(TAG, "Locked out $ip for $wait s")
                deny("locked", wait)
                return
            }
            if (!MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())) {
                registerFailure(ip)
                Log.w(TAG, "Wrong PIN from $ip (${given.length} digits entered)")
                deny("bad-pin", 0)
                return
            }
            fails.remove(ip)
            authorized = true
            clients.add(this)
            try {
                send(metaJson())
            } catch (e: IOException) {
                kill()
                return
            }
            pump = Thread({ pumpLoop() }, "ws-pump").apply { isDaemon = true; start() }
            onViewers(clients.size)
        }

        private fun deny(reason: String, wait: Int) {
            try {
                send(JSONObject().put("type", "denied").put("reason", reason).put("wait", wait).toString())
                close(CloseCode.PolicyViolation, reason, false)
            } catch (e: IOException) {
                // browser already gone
            }
        }

        override fun onPong(pong: WebSocketFrame?) {}

        override fun onException(exception: IOException?) = kill()

        fun pushVideo(p: ByteArray) {
            if (!alive || !authorized || pendingVideo.get() > 0) return   // viewer is behind: drop frame
            pendingVideo.incrementAndGet()
            if (!queue.offerLast(p)) pendingVideo.decrementAndGet()
        }

        fun pushAudio(p: ByteArray) {
            if (!alive || !authorized) return
            while (!queue.offerLast(p)) {
                val dropped = queue.pollFirst()
                if (dropped != null && dropped[0] == PKT_VIDEO) pendingVideo.decrementAndGet()
            }
        }

        private fun pumpLoop() {
            try {
                while (alive) {
                    val p = queue.take()
                    try {
                        send(p)
                    } finally {
                        if (p[0] == PKT_VIDEO) pendingVideo.decrementAndGet()
                    }
                }
            } catch (e: InterruptedException) {
                // normal shutdown
            } catch (e: IOException) {
                Log.d(TAG, "Viewer went away: ${e.message}")
            }
            kill()
        }

        fun kill() {
            if (!alive) return
            alive = false
            pump?.interrupt()
            if (clients.remove(this)) onViewers(clients.size)
            try {
                close(CloseCode.NormalClosure, "bye", false)
            } catch (e: IOException) {
                // socket already gone
            }
        }
    }
}
