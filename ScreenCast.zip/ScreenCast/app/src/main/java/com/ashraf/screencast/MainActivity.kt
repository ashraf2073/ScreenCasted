/* Made par Ashraf */
package com.ashraf.screencast

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val Mint = Color(0xFF7DE3C3)
private val Sky = Color(0xFF8EC9FF)
private val Amber = Color(0xFFFFD180)
private val Danger = Color(0xFFFF8A80)

class MainActivity : ComponentActivity() {

    private var wantAudio = false

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, ScreenStreamService::class.java)
                    .setAction(ScreenStreamService.ACTION_START)
                    .putExtra(ScreenStreamService.EXTRA_CODE, result.resultCode)
                    .putExtra(ScreenStreamService.EXTRA_DATA, data)
                    .putExtra(ScreenStreamService.EXTRA_AUDIO, wantAudio)
                ContextCompat.startForegroundService(this, intent)
            } else {
                StreamState.update { it.copy(error = "Screen-capture permission was declined.") }
            }
        }

    // Whatever the user answers (notifications / audio), continue to the capture dialog.
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { launchProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Mint, onPrimary = Color.Black, secondary = Sky,
                    background = Color(0xFF070B14), surface = Color(0xFF111A2E)
                )
            ) {
                MainScreen(onStart = ::begin, onStop = ::stopStreaming, onTether = ::openTetherSettings)
            }
        }
    }

    private fun begin(audio: Boolean) {
        wantAudio = audio
        StreamState.update { it.copy(error = null) }
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (audio && Build.VERSION.SDK_INT >= 29) add(Manifest.permission.RECORD_AUDIO)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

        if (needed.isEmpty()) launchProjection() else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun launchProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())   // standard system dialog
    }

    private fun stopStreaming() {
        startService(Intent(this, ScreenStreamService::class.java).setAction(ScreenStreamService.ACTION_STOP))
    }

    /** USB / Bluetooth tethering can only be switched on by the user; jump to the right settings page. */
    private fun openTetherSettings() {
        val candidates = listOf(
            Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS)
        )
        for (i in candidates) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // try the next one
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------------------------

@Composable
private fun MainScreen(onStart: (Boolean) -> Unit, onStop: () -> Unit, onTether: () -> Unit) {
    val ui by StreamState.state.collectAsStateWithLifecycle()

    Surface(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF070B14), Color(0xFF0F1830), Color(0xFF05070D)))),
        color = Color.Transparent,
        contentColor = Color.White
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier.offset(x = (-100).dp, y = (-80).dp).size(320.dp)
                    .background(Brush.radialGradient(listOf(Mint.copy(alpha = .20f), Color.Transparent)), CircleShape)
            )
            Box(
                Modifier.align(Alignment.BottomEnd).offset(x = 110.dp, y = 90.dp).size(320.dp)
                    .background(Brush.radialGradient(listOf(Sky.copy(alpha = .16f), Color.Transparent)), CircleShape)
            )
            Column(
                Modifier.systemBarsPadding().verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Header(ui.running)
                ui.error?.let { Glass { Text(it, color = Danger, fontSize = 14.sp) } }
                if (ui.running) Live(ui, onStop) else Idle(onStart, onTether)
                Text(
                    "Made par Ashraf",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    textAlign = TextAlign.Center,
                    color = Color.White.copy(alpha = .5f),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun Header(live: Boolean) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("ScreenCast", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Show this phone in any browser", color = Color.White.copy(alpha = .6f), fontSize = 14.sp)
        }
        Text(
            if (live) "● Live" else "○ Idle",
            color = if (live) Mint else Color.White.copy(alpha = .55f),
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = .08f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun Idle(onStart: (Boolean) -> Unit, onTether: () -> Unit) {
    var consentScreen by rememberSaveable { mutableStateOf(false) }
    var consentNetwork by rememberSaveable { mutableStateOf(false) }
    var audio by rememberSaveable { mutableStateOf(false) }

    Glass {
        Text("Before you start", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        ConsentRow(
            consentScreen, { consentScreen = it },
            "I consent to this app capturing my screen, including notifications, messages and any private content shown on it."
        )
        ConsentRow(
            consentNetwork, { consentNetwork = it },
            "I understand that anyone on the same network or cable who opens the address shown can watch this stream, and I will stop it when I'm done."
        )
        if (Build.VERSION.SDK_INT >= 29) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Also stream phone audio (apps can block this)",
                    modifier = Modifier.weight(1f), fontSize = 14.sp, color = Color.White.copy(alpha = .85f)
                )
                Switch(checked = audio, onCheckedChange = { audio = it })
            }
        }
        Button(
            onClick = { onStart(audio) },
            enabled = consentScreen && consentNetwork,
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("Start mirroring", fontWeight = FontWeight.SemiBold) }
    }

    Glass {
        Text("Connect with", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Text("USB cable: plug into the laptop and switch on USB tethering (fastest, steadiest).", fontSize = 14.sp, color = Color.White.copy(alpha = .75f))
        Text("Wi-Fi hotspot or the same Wi-Fi network: just open the address shown after you start.", fontSize = 14.sp, color = Color.White.copy(alpha = .75f))
        Text("Bluetooth: pair the laptop and switch on Bluetooth tethering. Expect a low frame rate.", fontSize = 14.sp, color = Color.White.copy(alpha = .75f))
        OutlinedButton(onClick = onTether, modifier = Modifier.fillMaxWidth()) { Text("Open tethering settings") }
    }
}

@Composable
private fun Live(ui: UiState, onStop: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val primary = ui.endpoints.firstOrNull()

    Glass {
        Text("Open this address in your laptop's browser", fontSize = 13.sp, color = Color.White.copy(alpha = .65f))
        if (primary != null) {
            Text(primary.url, color = Mint, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Connected through ${primary.type.label} (${primary.iface})", fontSize = 13.sp, color = Color.White.copy(alpha = .65f))
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(primary.url)) }) { Text("Copy address") }
        } else {
            Text(
                "No usable network yet. Join Wi-Fi, turn on the hotspot, or switch on USB tethering. This updates by itself.",
                color = Amber, fontSize = 14.sp
            )
        }
    }

    Glass {
        Text(
            if (ui.viewers == 1) "1 viewer connected" else "${ui.viewers} viewers connected",
            fontSize = 16.sp, fontWeight = FontWeight.SemiBold
        )
        Text(
            "Anyone who opens the address can watch, so stop mirroring when you're done.",
            fontSize = 13.sp, color = Color.White.copy(alpha = .6f)
        )
    }

    if (ui.endpoints.size > 1) {
        Glass {
            Text("Other addresses", fontSize = 13.sp, color = Color.White.copy(alpha = .65f))
            ui.endpoints.drop(1).forEach {
                Text("${it.type.label}: ${it.url}", fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
        }
    }

    if (ui.endpoints.any { it.type == LinkType.BLUETOOTH }) {
        Glass {
            Text(
                "Bluetooth is slow (about 1–3 Mbit/s in practice). Expect lag and a low frame rate; " +
                    "the low-bandwidth preset (480 px, 10 fps) is used when Bluetooth is the only link. " +
                    "USB or Wi-Fi is much smoother.",
                color = Amber, fontSize = 14.sp
            )
        }
    }

    Glass {
        Text(
            "Streaming at up to ${ui.config.maxEdge}px, quality ${ui.config.quality}, ${ui.config.fps} fps" +
                if (ui.audio) ", with audio" else "",
            fontSize = 14.sp, color = Color.White.copy(alpha = .8f)
        )
        Text("Viewers change these from the browser.", fontSize = 12.sp, color = Color.White.copy(alpha = .5f))
    }

    Button(
        onClick = onStop,
        colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = Color.Black),
        modifier = Modifier.fillMaxWidth().height(54.dp)
    ) { Text("Stop mirroring", fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun ConsentRow(checked: Boolean, onChange: (Boolean) -> Unit, text: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onChange(!checked) },
        verticalAlignment = Alignment.Top
    ) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(
            text,
            fontSize = 14.sp, lineHeight = 20.sp, color = Color.White.copy(alpha = .85f),
            modifier = Modifier.padding(top = 12.dp, end = 4.dp)
        )
    }
}

/** Frosted-glass card: translucent gradient fill plus a hairline highlight border. */
@Composable
private fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = modifier.fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .11f), Color.White.copy(alpha = .04f))))
            .border(1.dp, Color.White.copy(alpha = .14f), shape)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}
