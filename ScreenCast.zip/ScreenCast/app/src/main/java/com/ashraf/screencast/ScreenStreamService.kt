/* Made par Ashraf */
package com.ashraf.screencast

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.security.SecureRandom
import java.util.Locale

/**
 * Owns the whole mirroring session:
 *   MediaProjection -> VirtualDisplay -> ImageReader -> JPEG -> EmbeddedServer -> browsers
 * Runs as a mediaProjection-type foreground service (required on Android 10+ and enforced on 14+).
 */
class ScreenStreamService : Service() {

    companion object {
        const val ACTION_START = "com.ashraf.screencast.START"
        const val ACTION_STOP = "com.ashraf.screencast.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_AUDIO = "audio"
        private const val CHANNEL_ID = "screencast_stream"
        private const val NOTIF_ID = 42
        private const val BASE_PORT = 8080
        private const val TAG = "ScreenStream"
    }

    private val main = Handler(Looper.getMainLooper())

    private var running = false
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var server: EmbeddedServer? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    @Volatile private var config = StreamConfig()

    // Touched only on the capture thread:
    private var bitmap: Bitmap? = null
    private var frameW = 0
    private var dirty = false
    private var lastEncodeAt = 0L
    private val jpeg = ByteArrayOutputStream(256 * 1024)
    private val trailing = Runnable { if (dirty) encodeFrame() }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {            // user revoked via system UI / status-bar chip
            main.post { stopEverything() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startStreaming(intent)
            ACTION_STOP -> stopEverything()
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)          // rotation -> resize capture surface
        captureHandler?.post { applyCapture() }
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }

    // ---- Start ---------------------------------------------------------------------------

    private fun startStreaming(intent: Intent) {
        ensureChannel()
        // Must be foreground BEFORE getMediaProjection() on Android 14+.
        startAsForeground(buildNotification(null))
        if (running) return

        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data = intent.projectionData()
        if (code != Activity.RESULT_OK || data == null) {
            stopEverything("Screen-capture permission was not granted.")
            return
        }

        try {
            running = true
            acquireLocks()

            captureThread = HandlerThread("screen-capture").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)

            val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(projectionCallback, captureHandler)   // mandatory on Android 14+

            val pin = String.format(Locale.US, "%06d", SecureRandom().nextInt(1_000_000))
            val srv = startServer(pin) ?: throw IOException("Could not open a local port (8080-8090).")
            server = srv

            val endpoints = NetworkInfoProvider.discover(srv.listeningPort)
            if (endpoints.isNotEmpty() && endpoints.all { it.type == LinkType.BLUETOOTH }) {
                config = StreamConfig.LOW_BANDWIDTH
            }
            val audioOn = intent.getBooleanExtra(EXTRA_AUDIO, false) &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && startAudio(proj)

            StreamState.update {
                UiState(running = true, endpoints = endpoints, pin = pin, config = config, audio = audioOn)
            }
            captureHandler?.post { applyCapture() }
            main.postDelayed(refresher, 3_000)
            updateNotification()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start", e)
            stopEverything(e.message ?: "Failed to start mirroring.")
        }
    }

    private fun startServer(pin: String): EmbeddedServer? {
        for (port in BASE_PORT..BASE_PORT + 10) {
            val s = EmbeddedServer(applicationContext, port, pin, ::onViewers, ::onRemoteConfig)
            try {
                s.start(0, false)          // 0 = no socket read timeout (WebSocket idles are normal)
                return s
            } catch (e: IOException) {
                Log.d(TAG, "Port $port busy, trying next")
            }
        }
        return null
    }

    // ---- Capture pipeline ----------------------------------------------------------------

    /** (Re)builds ImageReader + VirtualDisplay for the current rotation and resolution setting. */
    private fun applyCapture() {
        val proj = projection ?: return
        if (!running) return

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)

        val scale = minOf(1f, config.maxEdge.toFloat() / maxOf(dm.widthPixels, dm.heightPixels))
        // Width multiple of 16 keeps ImageReader row stride == width*4 on virtually all devices.
        val w = ((dm.widthPixels * scale).toInt() and 0xF.inv()).coerceAtLeast(16)
        val h = ((dm.heightPixels * scale).toInt() and 1.inv()).coerceAtLeast(2)

        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener({ r -> onImage(r) }, captureHandler)

        val vd = display
        if (vd == null) {
            display = proj.createVirtualDisplay(
                "ScreenCast", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, captureHandler
            )
        } else {
            vd.resize(w, h, dm.densityDpi)
            vd.surface = newReader.surface
        }
        val old = reader
        reader = newReader
        old?.setOnImageAvailableListener(null, null)
        old?.close()
    }

    private fun onImage(r: ImageReader) {
        val image = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val plane = image.planes[0]
            val paddedW = plane.rowStride / plane.pixelStride
            val target = bitmap?.takeIf { it.width == paddedW && it.height == image.height }
                ?: Bitmap.createBitmap(paddedW, image.height, Bitmap.Config.ARGB_8888)
                    .also { bitmap?.recycle(); bitmap = it }
            target.copyPixelsFromBuffer(plane.buffer)     // cheap memcpy; keeps last frame for new viewers
            frameW = image.width

            val s = server
            if (s == null || !s.hasViewers()) return

            val wait = lastEncodeAt + 1000L / config.fps - SystemClock.elapsedRealtime()
            if (wait <= 0) {
                encodeFrame()
            } else {
                // Rate-limited: schedule one trailing encode so a static screen always ends on the latest frame.
                dirty = true
                captureHandler?.removeCallbacks(trailing)
                captureHandler?.postDelayed(trailing, wait)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Frame skipped: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun encodeFrame() {
        val bmp = bitmap ?: return
        val s = server ?: return
        if (!s.hasViewers()) return
        dirty = false
        lastEncodeAt = SystemClock.elapsedRealtime()

        jpeg.reset()
        jpeg.write(EmbeddedServer.PKT_VIDEO.toInt())               // header byte, then JPEG data
        val out = if (bmp.width != frameW) Bitmap.createBitmap(bmp, 0, 0, frameW, bmp.height) else bmp
        out.compress(Bitmap.CompressFormat.JPEG, config.quality, jpeg)
        if (out !== bmp) out.recycle()
        s.broadcast(jpeg.toByteArray())
    }

    // ---- Callbacks from the server -------------------------------------------------------

    private fun onViewers(count: Int) {
        StreamState.update { it.copy(viewers = count) }
        if (count > 0) captureHandler?.post { encodeFrame() }      // give a joining viewer an instant picture
    }

    private fun onRemoteConfig(cfg: StreamConfig) {
        config = cfg
        StreamState.update { it.copy(config = cfg) }
        captureHandler?.post { applyCapture() }
    }

    // ---- Optional device audio (API 29+) -------------------------------------------------

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun startAudio(proj: MediaProjection): Boolean {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val capture = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(AUDIO_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val min = AudioRecord.getMinBufferSize(
                AUDIO_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(capture)
                .setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(min, 8192) * 2)
                .build()
            rec.startRecording()
            audioRecord = rec
            audioThread = Thread({
                val chunk = 7056                              // 40 ms of 44.1 kHz stereo 16-bit
                val buf = ByteArray(1 + chunk)
                buf[0] = EmbeddedServer.PKT_AUDIO
                while (!Thread.currentThread().isInterrupted) {
                    val n = rec.read(buf, 1, chunk)
                    if (n < 0) break
                    if (n > 0 && server?.hasViewers() == true) server?.broadcast(buf.copyOf(1 + n))
                }
            }, "audio-capture").apply { isDaemon = true; start() }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Audio capture unavailable: ${e.message}")
            false
        }
    }

    // ---- Network refresh (user may enable USB/BT tethering after starting) ---------------

    private val refresher = object : Runnable {
        override fun run() {
            val port = server?.listeningPort ?: return
            val eps = NetworkInfoProvider.discover(port)
            if (eps != StreamState.state.value.endpoints) {
                StreamState.update { it.copy(endpoints = eps) }
                updateNotification()
            }
            main.postDelayed(this, 3_000)
        }
    }

    // ---- Stop ----------------------------------------------------------------------------

    private fun stopEverything(error: String? = null) {
        main.removeCallbacks(refresher)
        if (running) {
            running = false
            runCatching { audioThread?.interrupt() }
            runCatching { audioRecord?.stop(); audioRecord?.release() }
            runCatching { server?.shutdown() }
            runCatching { display?.release() }
            runCatching { reader?.setOnImageAvailableListener(null, null); reader?.close() }
            runCatching { projection?.unregisterCallback(projectionCallback); projection?.stop() }
            runCatching { captureThread?.quitSafely() }
            releaseLocks()
        }
        audioThread = null; audioRecord = null; server = null; display = null
        reader = null; projection = null; captureThread = null; captureHandler = null; bitmap = null
        StreamState.update { UiState(error = error) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---- Locks ---------------------------------------------------------------------------

    private fun acquireLocks() {
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScreenCast:stream")
            .apply { setReferenceCounted(false); acquire() }
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = applicationContext.getSystemService(WifiManager::class.java)
            ?.createWifiLock(mode, "ScreenCast:wifi")?.apply { setReferenceCounted(false); acquire() }
    }

    private fun releaseLocks() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        runCatching { if (wifiLock?.isHeld == true) wifiLock?.release() }
        wakeLock = null; wifiLock = null
    }

    // ---- Notification --------------------------------------------------------------------

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Screen mirroring", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun startAsForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        val url = StreamState.state.value.endpoints.firstOrNull()?.url
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(url))
    }

    private fun buildNotification(url: String?): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenStreamService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_cast)
            .setContentTitle("Screen mirroring is live")
            .setContentText(url ?: "Starting…")
            .setSubText("Made par Ashraf")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(open)
            .addAction(R.drawable.ic_cast, "Stop", stop)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun Intent.projectionData(): Intent? =
        if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else getParcelableExtra(EXTRA_DATA)
}
