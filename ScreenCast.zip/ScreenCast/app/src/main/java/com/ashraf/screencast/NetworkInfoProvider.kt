/* Made par Ashraf */
package com.ashraf.screencast

import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Finds the phone's IPv4 addresses and labels each by the kind of link it sits on.
 * Interface names vary by vendor, so the match is heuristic (name first, then well-known subnets).
 */
object NetworkInfoProvider {

    fun discover(port: Int): List<Endpoint> {
        val found = mutableListOf<Endpoint>()
        val interfaces = try {
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
        for (ni in interfaces) {
            try {
                if (!ni.isUp || ni.isLoopback) continue
                val name = ni.name.lowercase()
                for (addr in ni.inetAddresses) {
                    if (addr !is Inet4Address || addr.isLoopbackAddress || addr.isLinkLocalAddress) continue
                    val ip = addr.hostAddress ?: continue
                    val type = classify(name, ip) ?: continue
                    found += Endpoint(type, ni.name, ip, "http://$ip:$port")
                }
            } catch (e: Exception) {
                // Interface vanished while enumerating (e.g. cable unplugged) - skip it.
            }
        }
        return found.distinctBy { it.url }.sortedBy { it.type.rank }
    }

    private fun classify(iface: String, ip: String): LinkType? = when {
        // USB tethering: rndis0 / usb0 / ncm0 (Android's default USB gateway is 192.168.42.129)
        iface.startsWith("rndis") || iface.startsWith("usb") || iface.startsWith("ncm") ||
            ip.startsWith("192.168.42.") -> LinkType.USB

        // Bluetooth PAN tethering: bt-pan / bnep0 (default 192.168.44.1)
        iface.startsWith("bt-pan") || iface.startsWith("bnep") ||
            ip.startsWith("192.168.44.") -> LinkType.BLUETOOTH

        // Phone acting as access point: ap0 / swlan0 / softap0, or the classic 192.168.43.1
        iface.startsWith("ap") || iface.startsWith("swlan") || iface.startsWith("softap") ||
            ip == "192.168.43.1" -> LinkType.HOTSPOT

        // Regular Wi-Fi client or Ethernet dongle
        iface.startsWith("wlan") || iface.startsWith("eth") -> LinkType.WIFI

        // rmnet*/ccmni*/tun* = cellular or VPN: not reachable from a laptop, ignore.
        else -> null
    }
}
